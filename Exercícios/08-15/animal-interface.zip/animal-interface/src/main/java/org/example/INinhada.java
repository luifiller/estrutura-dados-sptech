package org.example;

public interface INinhada {
    public Integer getNinhadaPorAno();
}
