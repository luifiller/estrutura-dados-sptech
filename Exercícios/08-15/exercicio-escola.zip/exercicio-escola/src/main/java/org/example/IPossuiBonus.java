package org.example;

public interface IPossuiBonus {
    public Double getValorBonus();
}
