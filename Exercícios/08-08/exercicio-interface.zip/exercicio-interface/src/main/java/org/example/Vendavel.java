package org.example;

public interface Vendavel {
    public abstract Double getValorVenda();
}
